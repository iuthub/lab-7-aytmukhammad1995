# Lab 7


### Student Details:

- **Student ID**: u1710167
- **Student Name**: Sobirov Bilol
- **Section Number**: 003